package comm;

public enum Command {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    BOMB
}
