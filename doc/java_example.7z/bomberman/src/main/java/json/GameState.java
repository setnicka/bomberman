package json;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class GameState {
    @SerializedName("Name")
    String name;
    @SerializedName("X")
    int x;
    @SerializedName("Y")
    int y;
    @SerializedName("LastX")
    int lastX;
    @SerializedName("LastY")
    int lastY;
    @SerializedName("Bombs")
    int bombs;
    @SerializedName("MaxBombs")
    int maxBombs;
    @SerializedName("Radius")
    int radius;
    @SerializedName("Alive")
    boolean alive;
    @SerializedName("Points")
    int points;
    @SerializedName("Turn")
    public int turn;//: 55, // číslo tahu
    @SerializedName("Board")
    public ArrayList<String> board;
    @SerializedName("Players")
    public ArrayList<Player> players;
}
