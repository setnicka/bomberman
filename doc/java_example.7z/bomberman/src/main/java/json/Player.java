package json;

import com.google.gson.annotations.SerializedName;

public class Player {
    @SerializedName("Name")
    String name;
    @SerializedName("X")
    int x;
    @SerializedName("Y")
    int y;
    @SerializedName("LastX")
    int lastX;
    @SerializedName("LastY")
    int lastY;
    @SerializedName("Bombs")
    int bombs;
    @SerializedName("MaxBombs")
    int maxBombs;
    @SerializedName("Radius")
    int radius;
    @SerializedName("Alive")
    boolean alive;
    @SerializedName("Points")
    int points;
}
