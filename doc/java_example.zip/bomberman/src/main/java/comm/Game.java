package comm;

import json.Config;
import json.GameState;

public interface Game {
    void onGameConfig(Config c);
    void onGameState(GameState gameState, Client client);
}
