package comm;

import com.google.gson.Gson;
import json.Config;
import json.GameState;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class Client extends WebSocketClient {

    private boolean firstMsg;
    private String token;
    private Game game;

    public Client(String uri, String token, Game game) {
        super(URI.create(uri));
        this.token = token;
        this.game = game;
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("[LIB] Spojeni navazano...");
        send(token);
        System.out.println("[LIB] Autentifikovano...");
    }

    @Override
    public void onMessage(String message) {
        Gson gson = new Gson();
        if (firstMsg) {
            firstMsg = false;
            Config c = gson.fromJson(message, Config.class);
            handleConfigMessage(c);
        } else {
            GameState gs = gson.fromJson(message, GameState.class);
            handleGameStateMsg(gs);
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("[LIB] Spojeni ukonceno...");
    }

    @Override
    public void onError(Exception ex) {
        System.err.println("[LIB] KOMUNIKACNI CHYBA!!!");
        System.out.println("[LIB] Znovu se pripojuji...");
        firstMsg = true;
        this.reconnect();
    }

    private void handleConfigMessage(Config config) {
        game.onGameConfig(config);
    }

    private void handleGameStateMsg(GameState gameState) {
        game.onGameState(gameState, this);
    }

    public void sendCommand(Command c) {
        switch (c) {
            case BOMB:
                this.send("bomb");
                break;
            case UP:
                this.send("up");
                 break;
            case DOWN:
                this.send("down");
                break;
            case LEFT:
                this.send("left");
                break;
            case RIGHT:
                this.send("right");
                break;
        }
    }
}
