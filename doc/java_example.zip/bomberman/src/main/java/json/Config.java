package json;

import com.google.gson.annotations.SerializedName;

public class Config {
    @SerializedName("turns_to_flameout")
    public int turnsToFlamout; //": 1, // jak dlouho žije oheň
    @SerializedName("turns_to_replenish_used_bomb")
    public int turnsToReplenishUsedBomb; //": 12, // za jak dlouho se přičte bomba
    @SerializedName("turns_to_explode")
    public int turnsToExplode; //": 10, // za jak dlouho bomba exploduje
    @SerializedName("points_per_wall")
    public int pointsPerWall; //": 1, // kolik je bodů za zničení jedné zdi
    @SerializedName("points_per_suicide")
    public int pointsPerSuicide; //": -10 // kolik je bodů za zabití sám sebe
    @SerializedName("points_per_kill")
    public int pointsPerKill; //": 10, // kolik je bodů za zabití hráče
}
